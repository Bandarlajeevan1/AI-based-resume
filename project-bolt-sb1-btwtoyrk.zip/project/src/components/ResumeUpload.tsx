import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Loader, X, Download } from 'lucide-react';
import { UserProfile, ResumeAnalysis } from '../types';
import { analyzeResume } from '../services/resumeService';

interface ResumeUploadProps {
  userProfile: UserProfile;
  onAnalysisComplete: (analysis: ResumeAnalysis, updatedProfile: UserProfile) => void;
  onSkip: () => void;
}

const ResumeUpload: React.FC<ResumeUploadProps> = ({ 
  userProfile, 
  onAnalysisComplete, 
  onSkip 
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [error, setError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  };

  const handleFile = (file: File) => {
    setError('');
    
    // Validate file type
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    if (!allowedTypes.includes(file.type)) {
      setError('Please upload a PDF, DOC, DOCX, or TXT file');
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      setError('File size must be less than 5MB');
      return;
    }

    setUploadedFile(file);
  };

  const handleAnalyze = async () => {
    if (!uploadedFile) return;

    setIsAnalyzing(true);
    setError('');

    try {
      const fileContent = await readFileContent(uploadedFile);
      const resumeAnalysis = await analyzeResume(fileContent, uploadedFile.name);
      
      setAnalysis(resumeAnalysis);
      setIsAnalyzing(false);
    } catch (err) {
      setError('Failed to analyze resume. Please try again.');
      setIsAnalyzing(false);
    }
  };

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve(content);
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const handleAcceptAnalysis = () => {
    if (!analysis) return;

    const updatedProfile: UserProfile = {
      ...userProfile,
      name: analysis.contactInfo.name || userProfile.name,
      email: analysis.contactInfo.email || userProfile.email,
      location: analysis.contactInfo.location || userProfile.location,
      skills: [...new Set([...userProfile.skills, ...analysis.extractedSkills])],
      interests: [...new Set([...userProfile.interests, ...analysis.suggestedInterests])],
      experience: analysis.detectedExperience || userProfile.experience,
      education: analysis.detectedEducation || userProfile.education,
      resumeContent: analysis.summary,
      resumeFileName: uploadedFile?.name
    };

    onAnalysisComplete(analysis, updatedProfile);
  };

  const removeFile = () => {
    setUploadedFile(null);
    setAnalysis(null);
    setError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm">
        {/* Header */}
        <div className="px-8 py-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Upload Your Resume</h2>
          <p className="text-gray-600 mt-1">
            Let our AI analyze your resume to extract skills and suggest personalized job matches
          </p>
        </div>

        <div className="p-8">
          {!uploadedFile ? (
            /* Upload Area */
            <div
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                dragActive 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Drop your resume here, or click to browse
              </h3>
              <p className="text-gray-600 mb-6">
                Supports PDF, DOC, DOCX, and TXT files up to 5MB
              </p>
              
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.doc,.docx,.txt"
                onChange={handleFileInput}
                className="hidden"
              />
              
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Choose File
              </button>
              
              {error && (
                <div className="mt-4 flex items-center justify-center text-red-600">
                  <AlertCircle className="w-4 h-4 mr-2" />
                  <span className="text-sm">{error}</span>
                </div>
              )}
            </div>
          ) : (
            /* File Uploaded */
            <div className="space-y-6">
              {/* File Info */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <FileText className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="font-medium text-gray-900">{uploadedFile.name}</p>
                    <p className="text-sm text-gray-600">
                      {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {!analysis && !isAnalyzing && (
                    <button
                      onClick={handleAnalyze}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                    >
                      Analyze Resume
                    </button>
                  )}
                  <button
                    onClick={removeFile}
                    className="text-gray-400 hover:text-gray-600 p-1"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Analysis Loading */}
              {isAnalyzing && (
                <div className="text-center py-12">
                  <Loader className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-spin" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Analyzing Your Resume
                  </h3>
                  <p className="text-gray-600">
                    Our AI is extracting skills, experience, and other relevant information...
                  </p>
                </div>
              )}

              {/* Analysis Results */}
              {analysis && (
                <div className="space-y-6">
                  <div className="flex items-center text-green-600 mb-4">
                    <CheckCircle className="w-6 h-6 mr-2" />
                    <span className="font-semibold">Analysis Complete!</span>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Contact Information */}
                    <div className="bg-gray-50 rounded-lg p-6">
                      <h4 className="font-semibold text-gray-900 mb-4">Contact Information</h4>
                      <div className="space-y-2 text-sm">
                        {analysis.contactInfo.name && (
                          <div>
                            <span className="text-gray-600">Name: </span>
                            <span className="text-gray-900">{analysis.contactInfo.name}</span>
                          </div>
                        )}
                        {analysis.contactInfo.email && (
                          <div>
                            <span className="text-gray-600">Email: </span>
                            <span className="text-gray-900">{analysis.contactInfo.email}</span>
                          </div>
                        )}
                        {analysis.contactInfo.phone && (
                          <div>
                            <span className="text-gray-600">Phone: </span>
                            <span className="text-gray-900">{analysis.contactInfo.phone}</span>
                          </div>
                        )}
                        {analysis.contactInfo.location && (
                          <div>
                            <span className="text-gray-600">Location: </span>
                            <span className="text-gray-900">{analysis.contactInfo.location}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Experience & Education */}
                    <div className="bg-gray-50 rounded-lg p-6">
                      <h4 className="font-semibold text-gray-900 mb-4">Experience & Education</h4>
                      <div className="space-y-2 text-sm">
                        <div>
                          <span className="text-gray-600">Experience Level: </span>
                          <span className="text-gray-900 capitalize">{analysis.detectedExperience}</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Education: </span>
                          <span className="text-gray-900 capitalize">{analysis.detectedEducation}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Extracted Skills */}
                  <div className="bg-blue-50 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">
                      Extracted Skills ({analysis.extractedSkills.length})
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {analysis.extractedSkills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Suggested Interests */}
                  <div className="bg-green-50 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">
                      Suggested Interests ({analysis.suggestedInterests.length})
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {analysis.suggestedInterests.map((interest) => (
                        <span
                          key={interest}
                          className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium"
                        >
                          {interest}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Summary */}
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Resume Summary</h4>
                    <p className="text-gray-700 text-sm leading-relaxed">{analysis.summary}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex justify-between items-center pt-6 border-t">
                    <button
                      onClick={onSkip}
                      className="text-gray-600 hover:text-gray-800 font-medium"
                    >
                      Skip for now
                    </button>
                    
                    <div className="space-x-3">
                      <button
                        onClick={removeFile}
                        className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                      >
                        Upload Different Resume
                      </button>
                      <button
                        onClick={handleAcceptAnalysis}
                        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                      >
                        Use This Analysis
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Skip Option */}
          {!uploadedFile && (
            <div className="mt-8 text-center">
              <button
                onClick={onSkip}
                className="text-gray-600 hover:text-gray-800 font-medium"
              >
                Skip resume upload and continue manually
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResumeUpload;