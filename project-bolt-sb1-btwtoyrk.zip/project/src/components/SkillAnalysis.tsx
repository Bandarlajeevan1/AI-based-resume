import React from 'react';
import { TrendingUp, Target, Award, BookOpen, BarChart3 } from 'lucide-react';
import { UserProfile } from '../types';

interface SkillAnalysisProps {
  userProfile: UserProfile;
}

const SkillAnalysis: React.FC<SkillAnalysisProps> = ({ userProfile }) => {
  // Simulated skill analysis data
  const skillAnalysis = userProfile.skills.map(skill => ({
    skill,
    proficiency: Math.floor(Math.random() * 40) + 60,
    demand: Math.floor(Math.random() * 30) + 70,
    growth: Math.floor(Math.random() * 20) + 5,
    recommendations: [
      `Consider getting certified in ${skill}`,
      `Build projects using ${skill}`,
      `Join communities focused on ${skill}`
    ]
  }));

  const skillGaps = [
    'Cloud Computing (AWS/Azure)',
    'Docker & Kubernetes',
    'GraphQL',
    'Mobile Development',
    'DevOps Practices'
  ];

  const trendingSkills = [
    { skill: 'Artificial Intelligence', growth: 95, demand: 92 },
    { skill: 'Machine Learning', growth: 88, demand: 85 },
    { skill: 'Cybersecurity', growth: 82, demand: 89 },
    { skill: 'Cloud Computing', growth: 79, demand: 91 },
    { skill: 'Data Science', growth: 76, demand: 87 }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-lg p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Skill Analysis Dashboard</h1>
        <p className="text-purple-100">Deep insights into your skills and market opportunities</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between mb-2">
            <Target className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">{userProfile.skills.length}</span>
          </div>
          <p className="text-sm font-medium text-gray-600">Total Skills</p>
          <p className="text-xs text-green-600 mt-1">+2 this month</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-green-600" />
            <span className="text-2xl font-bold text-gray-900">85%</span>
          </div>
          <p className="text-sm font-medium text-gray-600">Avg Proficiency</p>
          <p className="text-xs text-green-600 mt-1">+5% improvement</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between mb-2">
            <Award className="w-8 h-8 text-amber-600" />
            <span className="text-2xl font-bold text-gray-900">92%</span>
          </div>
          <p className="text-sm font-medium text-gray-600">Market Demand</p>
          <p className="text-xs text-amber-600 mt-1">High demand</p>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between mb-2">
            <BookOpen className="w-8 h-8 text-purple-600" />
            <span className="text-2xl font-bold text-gray-900">{skillGaps.length}</span>
          </div>
          <p className="text-sm font-medium text-gray-600">Skill Gaps</p>
          <p className="text-xs text-red-600 mt-1">Opportunities</p>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Your Skills Analysis */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <h2 className="text-xl font-bold text-gray-900 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
                Your Skills Analysis
              </h2>
            </div>
            
            <div className="p-6">
              <div className="space-y-6">
                {skillAnalysis.map((analysis) => (
                  <div key={analysis.skill} className="border rounded-lg p-4">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-semibold text-gray-900">{analysis.skill}</h3>
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                        {analysis.proficiency}% Proficiency
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <div className="text-xs text-gray-600 mb-1">Proficiency</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${analysis.proficiency}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-600 mt-1">{analysis.proficiency}%</div>
                      </div>
                      
                      <div>
                        <div className="text-xs text-gray-600 mb-1">Market Demand</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-600 h-2 rounded-full" 
                            style={{ width: `${analysis.demand}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-600 mt-1">{analysis.demand}%</div>
                      </div>
                      
                      <div>
                        <div className="text-xs text-gray-600 mb-1">Growth Rate</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-purple-600 h-2 rounded-full" 
                            style={{ width: `${analysis.growth * 5}%` }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-600 mt-1">+{analysis.growth}%</div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-xs font-medium text-gray-900 mb-2">Improvement Recommendations:</div>
                      <ul className="text-xs text-gray-600 space-y-1">
                        {analysis.recommendations.map((rec, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                            <span>{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Skill Gaps */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <h3 className="text-lg font-bold text-gray-900 flex items-center">
                <Target className="w-5 h-5 mr-2 text-red-600" />
                Skill Gaps to Address
              </h3>
            </div>
            
            <div className="p-6">
              <div className="space-y-3">
                {skillGaps.map((gap, index) => (
                  <div key={gap} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <span className="text-sm font-medium text-red-800">{gap}</span>
                    <span className="text-xs text-red-600 bg-red-100 px-2 py-1 rounded-full">
                      Priority {index + 1}
                    </span>
                  </div>
                ))}
              </div>
              
              <button className="w-full mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                Get Learning Plan
              </button>
            </div>
          </div>

          {/* Trending Skills */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <h3 className="text-lg font-bold text-gray-900 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-green-600" />
                Trending Skills
              </h3>
            </div>
            
            <div className="p-6">
              <div className="space-y-4">
                {trendingSkills.map((trend) => (
                  <div key={trend.skill} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-900">{trend.skill}</span>
                      <span className="text-xs text-green-600 font-medium">+{trend.growth}%</span>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-xs text-gray-600">
                        <span>Growth</span>
                        <span>{trend.growth}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div 
                          className="bg-green-600 h-1.5 rounded-full" 
                          style={{ width: `${trend.growth}%` }}
                        ></div>
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-xs text-gray-600">
                        <span>Demand</span>
                        <span>{trend.demand}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div 
                          className="bg-blue-600 h-1.5 rounded-full" 
                          style={{ width: `${trend.demand}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Learning Resources */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <h3 className="text-lg font-bold text-gray-900 flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-purple-600" />
                Recommended Learning
              </h3>
            </div>
            
            <div className="p-6">
              <div className="space-y-3">
                <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                  <div className="font-medium text-sm text-gray-900">AWS Cloud Practitioner</div>
                  <div className="text-xs text-gray-600">Industry certification</div>
                </div>
                
                <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                  <div className="font-medium text-sm text-gray-900">Advanced React Patterns</div>
                  <div className="text-xs text-gray-600">Online course</div>
                </div>
                
                <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                  <div className="font-medium text-sm text-gray-900">Machine Learning Basics</div>
                  <div className="text-xs text-gray-600">Specialization</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkillAnalysis;