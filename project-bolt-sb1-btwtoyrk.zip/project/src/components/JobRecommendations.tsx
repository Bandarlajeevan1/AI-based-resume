import React, { useState } from 'react';
import { Search, Filter, MapPin, Users, Clock, DollarSign, Star, ThumbsUp, ThumbsDown } from 'lucide-react';
import { UserProfile, JobRecommendation } from '../types';

interface JobRecommendationsProps {
  userProfile: UserProfile;
  jobRecommendations: JobRecommendation[];
}

const JobRecommendations: React.FC<JobRecommendationsProps> = ({ 
  userProfile, 
  jobRecommendations 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'match' | 'salary' | 'date'>('match');
  const [filterType, setFilterType] = useState<'all' | 'full-time' | 'part-time' | 'contract' | 'internship'>('all');
  const [feedback, setFeedback] = useState<Record<string, 'positive' | 'negative'>>({});

  const filteredJobs = jobRecommendations
    .filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          job.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === 'all' || job.type === filterType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'match':
          return b.matchScore - a.matchScore;
        case 'salary':
          return parseInt(b.salary.replace(/[^0-9]/g, '')) - parseInt(a.salary.replace(/[^0-9]/g, ''));
        case 'date':
          return Date.now() - Date.now(); // Placeholder for date sorting
        default:
          return 0;
      }
    });

  const handleFeedback = (jobId: string, type: 'positive' | 'negative') => {
    setFeedback(prev => ({ ...prev, [jobId]: type }));
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600 bg-green-50';
    if (score >= 70) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Job Recommendations</h1>
        <p className="text-gray-600">AI-powered job matches based on your skills and interests</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search jobs or companies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="flex items-center space-x-4">
            {/* Sort By */}
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="match">Best Match</option>
                <option value="salary">Salary</option>
                <option value="date">Date Posted</option>
              </select>
            </div>

            {/* Filter By Type */}
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Types</option>
                <option value="full-time">Full Time</option>
                <option value="part-time">Part Time</option>
                <option value="contract">Contract</option>
                <option value="internship">Internship</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mt-4 text-sm text-gray-600">
          Showing {filteredJobs.length} of {jobRecommendations.length} job recommendations
        </div>
      </div>

      {/* Job Cards */}
      <div className="space-y-6">
        {filteredJobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
            {/* Job Header */}
            <div className="p-6 border-b">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{job.title}</h3>
                  <div className="flex items-center space-x-4 text-gray-600">
                    <span className="flex items-center space-x-1">
                      <Users className="w-4 h-4" />
                      <span>{job.company}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <MapPin className="w-4 h-4" />
                      <span>{job.location}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span className="capitalize">{job.type}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <DollarSign className="w-4 h-4" />
                      <span>{job.salary}</span>
                    </span>
                  </div>
                </div>

                {/* Match Score */}
                <div className={`px-4 py-2 rounded-lg font-bold text-lg ${getMatchScoreColor(job.matchScore)}`}>
                  {job.matchScore}% Match
                </div>
              </div>

              {/* Match Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-blue-600">{job.skillsMatch}%</div>
                  <div className="text-xs text-gray-600">Skills Match</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-green-600">{job.interestsMatch}%</div>
                  <div className="text-xs text-gray-600">Interest Match</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-purple-600">{job.compatibilityScore}%</div>
                  <div className="text-xs text-gray-600">Compatibility</div>
                </div>
              </div>
            </div>

            {/* Job Details */}
            <div className="p-6">
              <p className="text-gray-700 mb-4 line-clamp-3">{job.description}</p>

              {/* Required Skills */}
              <div className="mb-4">
                <h4 className="text-sm font-semibold text-gray-900 mb-2">Required Skills:</h4>
                <div className="flex flex-wrap gap-2">
                  {job.requiredSkills.map((skill) => (
                    <span
                      key={skill}
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        userProfile.skills.includes(skill)
                          ? 'bg-green-100 text-green-700 border border-green-200'
                          : 'bg-red-100 text-red-700 border border-red-200'
                      }`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Skill Gaps */}
              {job.skillGaps.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Skills to Develop:</h4>
                  <div className="flex flex-wrap gap-2">
                    {job.skillGaps.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 rounded-full text-sm font-medium bg-orange-100 text-orange-700 border border-orange-200"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Match Reasons */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-2">Why This Job Matches:</h4>
                <ul className="space-y-1">
                  {job.matchReasons.map((reason, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center space-x-2">
                      <Star className="w-3 h-3 text-yellow-500" />
                      <span>{reason}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleFeedback(job.id, 'positive')}
                    className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      feedback[job.id] === 'positive'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-gray-100 text-gray-600 hover:bg-green-50'
                    }`}
                  >
                    <ThumbsUp className="w-4 h-4" />
                    <span>Helpful</span>
                  </button>
                  <button
                    onClick={() => handleFeedback(job.id, 'negative')}
                    className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                      feedback[job.id] === 'negative'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-gray-100 text-gray-600 hover:bg-red-50'
                    }`}
                  >
                    <ThumbsDown className="w-4 h-4" />
                    <span>Not Helpful</span>
                  </button>
                </div>

                <div className="space-x-3">
                  <button className="px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg font-medium transition-colors">
                    Save Job
                  </button>
                  <button className="px-6 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-medium transition-colors">
                    Apply Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* No Results */}
      {filteredJobs.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
          <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">No jobs found</h3>
          <p className="text-gray-600">Try adjusting your search terms or filters to find more opportunities.</p>
        </div>
      )}
    </div>
  );
};

export default JobRecommendations;