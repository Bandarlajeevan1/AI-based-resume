import React from 'react';
import { Briefcase, TrendingUp, Target, Star, ArrowRight, Users, MapPin } from 'lucide-react';
import { UserProfile, JobRecommendation } from '../types';

interface DashboardProps {
  userProfile: UserProfile;
  jobRecommendations: JobRecommendation[];
  onViewRecommendations: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  userProfile, 
  jobRecommendations, 
  onViewRecommendations 
}) => {
  const topJobs = jobRecommendations.slice(0, 3);
  const averageMatch = jobRecommendations.reduce((sum, job) => sum + job.matchScore, 0) / jobRecommendations.length || 0;

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {userProfile.name}!</h1>
        <p className="text-blue-100">Your AI-powered job matching dashboard is ready.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Job Matches</p>
              <p className="text-3xl font-bold text-gray-900">{jobRecommendations.length}</p>
            </div>
            <Briefcase className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Match Score</p>
              <p className="text-3xl font-bold text-gray-900">{averageMatch.toFixed(0)}%</p>
            </div>
            <Target className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Skills Tracked</p>
              <p className="text-3xl font-bold text-gray-900">{userProfile.skills.length}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-amber-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Interests</p>
              <p className="text-3xl font-bold text-gray-900">{userProfile.interests.length}</p>
            </div>
            <Star className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Profile Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Top Job Recommendations */}
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Top Job Matches</h2>
                <button
                  onClick={onViewRecommendations}
                  className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 font-medium"
                >
                  <span>View All</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              {topJobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900">{job.title}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                        <span className="flex items-center space-x-1">
                          <Users className="w-4 h-4" />
                          <span>{job.company}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <MapPin className="w-4 h-4" />
                          <span>{job.location}</span>
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-600">{job.matchScore}%</div>
                      <div className="text-xs text-gray-500">Match</div>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    {job.requiredSkills.slice(0, 4).map((skill) => (
                      <span
                        key={skill}
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          userProfile.skills.includes(skill)
                            ? 'bg-green-100 text-green-700'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {skill}
                      </span>
                    ))}
                    {job.requiredSkills.length > 4 && (
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                        +{job.requiredSkills.length - 4} more
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">{job.salary}</span>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      {job.type}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {/* Profile Summary */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Profile Summary</h3>
            <div className="space-y-3">
              <div>
                <span className="text-sm font-medium text-gray-600">Experience:</span>
                <span className="ml-2 text-sm text-gray-900 capitalize">{userProfile.experience}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600">Education:</span>
                <span className="ml-2 text-sm text-gray-900 capitalize">{userProfile.education}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600">Location:</span>
                <span className="ml-2 text-sm text-gray-900">{userProfile.location}</span>
              </div>
              <div>
                <span className="text-sm font-medium text-gray-600">Job Type:</span>
                <span className="ml-2 text-sm text-gray-900 capitalize">{userProfile.preferences.jobType}</span>
              </div>
            </div>
          </div>

          {/* Skills Overview */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Top Skills</h3>
            <div className="space-y-2">
              {userProfile.skills.slice(0, 8).map((skill) => (
                <div key={skill} className="flex justify-between items-center">
                  <span className="text-sm text-gray-700">{skill}</span>
                  <div className="w-20 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${Math.random() * 40 + 60}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <button 
                onClick={onViewRecommendations}
                className="w-full text-left px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100 transition-colors"
              >
                Browse All Jobs
              </button>
              <button className="w-full text-left px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100 transition-colors">
                Update Skills
              </button>
              <button className="w-full text-left px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100 transition-colors">
                Set Job Alerts
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;