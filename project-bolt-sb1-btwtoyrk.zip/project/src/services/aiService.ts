import { UserProfile, JobRecommendation } from '../types';

// Simulated job database
const jobDatabase: Omit<JobRecommendation, 'matchScore' | 'skillsMatch' | 'interestsMatch' | 'compatibilityScore' | 'skillGaps' | 'matchReasons'>[] = [
  {
    id: '1',
    title: 'Senior Full Stack Developer',
    company: 'TechCorp Inc.',
    location: 'San Francisco, CA',
    type: 'full-time',
    salary: '$120,000 - $160,000',
    description: 'Join our dynamic team to build cutting-edge web applications using modern technologies. You will work on scalable systems that serve millions of users.',
    requiredSkills: ['JavaScript', 'React', 'Node.js', 'TypeScript', 'SQL'],
    preferredSkills: ['AWS', 'Docker', 'GraphQL']
  },
  {
    id: '2',
    title: 'Data Scientist',
    company: 'DataFlow Analytics',
    location: 'New York, NY',
    type: 'full-time',
    salary: '$110,000 - $140,000',
    description: 'Analyze complex datasets to derive business insights and build predictive models. Work with cross-functional teams to implement data-driven solutions.',
    requiredSkills: ['Python', 'Machine Learning', 'Data Analysis', 'SQL'],
    preferredSkills: ['TensorFlow', 'R', 'Tableau']
  },
  {
    id: '3',
    title: 'Cloud Solutions Architect',
    company: 'CloudTech Solutions',
    location: 'Seattle, WA',
    type: 'full-time',
    salary: '$140,000 - $180,000',
    description: 'Design and implement scalable cloud infrastructure solutions for enterprise clients. Lead technical discussions and mentor junior developers.',
    requiredSkills: ['AWS', 'Docker', 'Kubernetes', 'DevOps'],
    preferredSkills: ['Terraform', 'Python', 'MongoDB']
  },
  {
    id: '4',
    title: 'Frontend Developer',
    company: 'Design Studios',
    location: 'Austin, TX',
    type: 'full-time',
    salary: '$85,000 - $110,000',
    description: 'Create beautiful and intuitive user interfaces for web applications. Collaborate with designers and backend developers to deliver exceptional user experiences.',
    requiredSkills: ['JavaScript', 'React', 'UI/UX Design', 'TypeScript'],
    preferredSkills: ['Vue.js', 'Figma', 'SASS']
  },
  {
    id: '5',
    title: 'Machine Learning Engineer',
    company: 'AI Innovations',
    location: 'Boston, MA',
    type: 'full-time',
    salary: '$130,000 - $170,000',
    description: 'Develop and deploy machine learning models at scale. Work on cutting-edge AI projects and contribute to our research initiatives.',
    requiredSkills: ['Python', 'Machine Learning', 'TensorFlow', 'Data Analysis'],
    preferredSkills: ['PyTorch', 'Kubernetes', 'MLOps']
  },
  {
    id: '6',
    title: 'Mobile App Developer',
    company: 'Mobile First',
    location: 'Los Angeles, CA',
    type: 'contract',
    salary: '$80 - $120 per hour',
    description: 'Build native mobile applications for iOS and Android platforms. Focus on performance optimization and user experience.',
    requiredSkills: ['Mobile Development', 'JavaScript', 'React'],
    preferredSkills: ['Swift', 'Kotlin', 'Flutter']
  },
  {
    id: '7',
    title: 'DevOps Engineer',
    company: 'Infrastructure Pro',
    location: 'Chicago, IL',
    type: 'full-time',
    salary: '$100,000 - $130,000',
    description: 'Maintain and optimize our CI/CD pipelines and cloud infrastructure. Ensure high availability and scalability of our systems.',
    requiredSkills: ['DevOps', 'Docker', 'AWS', 'Kubernetes'],
    preferredSkills: ['Jenkins', 'Terraform', 'Monitoring']
  },
  {
    id: '8',
    title: 'Cybersecurity Specialist',
    company: 'SecureNet',
    location: 'Washington, DC',
    type: 'full-time',
    salary: '$95,000 - $125,000',
    description: 'Protect our systems from security threats and implement security best practices. Conduct security audits and incident response.',
    requiredSkills: ['Cybersecurity', 'Python', 'Network Security'],
    preferredSkills: ['Penetration Testing', 'SIEM', 'Compliance']
  },
  {
    id: '9',
    title: 'Product Manager',
    company: 'Innovation Labs',
    location: 'Portland, OR',
    type: 'full-time',
    salary: '$110,000 - $140,000',
    description: 'Lead product development from conception to launch. Work with engineering and design teams to build products users love.',
    requiredSkills: ['Project Management', 'Data Analysis'],
    preferredSkills: ['Agile', 'User Research', 'A/B Testing']
  },
  {
    id: '10',
    title: 'Junior Software Developer',
    company: 'StartupX',
    location: 'Denver, CO',
    type: 'full-time',
    salary: '$65,000 - $85,000',
    description: 'Start your career in software development with our mentorship program. Work on real projects while learning from experienced developers.',
    requiredSkills: ['JavaScript', 'Python'],
    preferredSkills: ['React', 'Git', 'Databases']
  }
];

export function generateJobRecommendations(userProfile: UserProfile): JobRecommendation[] {
  return jobDatabase.map(job => {
    const matchScore = calculateMatchScore(userProfile, job);
    const skillsMatch = calculateSkillsMatch(userProfile.skills, job.requiredSkills);
    const interestsMatch = calculateInterestsMatch(userProfile.interests, job);
    const compatibilityScore = calculateCompatibilityScore(userProfile, job);
    const skillGaps = calculateSkillGaps(userProfile.skills, job.requiredSkills);
    const matchReasons = generateMatchReasons(userProfile, job, skillsMatch, interestsMatch);

    return {
      ...job,
      matchScore,
      skillsMatch,
      interestsMatch,
      compatibilityScore,
      skillGaps,
      matchReasons
    };
  }).sort((a, b) => b.matchScore - a.matchScore);
}

function calculateMatchScore(userProfile: UserProfile, job: Omit<JobRecommendation, 'matchScore' | 'skillsMatch' | 'interestsMatch' | 'compatibilityScore' | 'skillGaps' | 'matchReasons'>): number {
  const skillsMatch = calculateSkillsMatch(userProfile.skills, job.requiredSkills);
  const interestsMatch = calculateInterestsMatch(userProfile.interests, job);
  const typeMatch = userProfile.preferences.jobType === job.type ? 100 : 70;
  const experienceMatch = calculateExperienceMatch(userProfile.experience, job.title);
  
  // Weighted average
  const score = (skillsMatch * 0.4) + (interestsMatch * 0.2) + (typeMatch * 0.2) + (experienceMatch * 0.2);
  
  return Math.round(score);
}

function calculateSkillsMatch(userSkills: string[], requiredSkills: string[]): number {
  if (requiredSkills.length === 0) return 100;
  
  const matchingSkills = requiredSkills.filter(skill => 
    userSkills.some(userSkill => 
      userSkill.toLowerCase().includes(skill.toLowerCase()) || 
      skill.toLowerCase().includes(userSkill.toLowerCase())
    )
  );
  
  return Math.round((matchingSkills.length / requiredSkills.length) * 100);
}

function calculateInterestsMatch(userInterests: string[], job: Omit<JobRecommendation, 'matchScore' | 'skillsMatch' | 'interestsMatch' | 'compatibilityScore' | 'skillGaps' | 'matchReasons'>): number {
  const jobText = `${job.title} ${job.description}`.toLowerCase();
  
  const matchingInterests = userInterests.filter(interest =>
    jobText.includes(interest.toLowerCase()) ||
    interest.toLowerCase().includes('web') && jobText.includes('web') ||
    interest.toLowerCase().includes('mobile') && jobText.includes('mobile') ||
    interest.toLowerCase().includes('data') && jobText.includes('data') ||
    interest.toLowerCase().includes('ai') && jobText.includes('machine learning')
  );
  
  return userInterests.length > 0 ? Math.round((matchingInterests.length / userInterests.length) * 100) : 70;
}

function calculateCompatibilityScore(userProfile: UserProfile, job: Omit<JobRecommendation, 'matchScore' | 'skillsMatch' | 'interestsMatch' | 'compatibilityScore' | 'skillGaps' | 'matchReasons'>): number {
  let score = 70; // Base score
  
  // Location match
  if (userProfile.location.toLowerCase().includes(job.location.toLowerCase()) || 
      job.location.toLowerCase().includes('remote') ||
      userProfile.preferences.remoteWork) {
    score += 15;
  }
  
  // Experience level match
  const experienceBonus = calculateExperienceMatch(userProfile.experience, job.title);
  score += (experienceBonus - 70) * 0.5; // Convert to bonus/penalty
  
  // Salary expectations (simulated)
  score += Math.random() * 20 - 10; // Random adjustment for salary match
  
  return Math.round(Math.max(50, Math.min(100, score)));
}

function calculateExperienceMatch(userExperience: string, jobTitle: string): number {
  const isJunior = jobTitle.toLowerCase().includes('junior') || jobTitle.toLowerCase().includes('entry');
  const isSenior = jobTitle.toLowerCase().includes('senior') || jobTitle.toLowerCase().includes('lead');
  
  switch (userExperience) {
    case 'entry':
      return isJunior ? 95 : isSenior ? 50 : 80;
    case 'mid':
      return isJunior ? 85 : isSenior ? 75 : 95;
    case 'senior':
      return isJunior ? 70 : isSenior ? 95 : 90;
    case 'executive':
      return isJunior ? 60 : isSenior ? 85 : 80;
    default:
      return 70;
  }
}

function calculateSkillGaps(userSkills: string[], requiredSkills: string[]): string[] {
  return requiredSkills.filter(skill => 
    !userSkills.some(userSkill => 
      userSkill.toLowerCase().includes(skill.toLowerCase()) || 
      skill.toLowerCase().includes(userSkill.toLowerCase())
    )
  );
}

function generateMatchReasons(userProfile: UserProfile, job: Omit<JobRecommendation, 'matchScore' | 'skillsMatch' | 'interestsMatch' | 'compatibilityScore' | 'skillGaps' | 'matchReasons'>, skillsMatch: number, interestsMatch: number): string[] {
  const reasons: string[] = [];
  
  if (skillsMatch > 80) {
    reasons.push('Strong technical skill alignment with job requirements');
  } else if (skillsMatch > 60) {
    reasons.push('Good technical skill match with room for growth');
  }
  
  if (interestsMatch > 70) {
    reasons.push('Your interests align well with the job domain');
  }
  
  if (userProfile.preferences.jobType === job.type) {
    reasons.push(`Matches your preferred job type: ${job.type}`);
  }
  
  const experienceMatch = calculateExperienceMatch(userProfile.experience, job.title);
  if (experienceMatch > 85) {
    reasons.push('Perfect experience level match for this role');
  }
  
  if (userProfile.preferences.remoteWork && job.location.includes('Remote')) {
    reasons.push('Offers remote work options you prefer');
  }
  
  // Add some specific matching skills
  const matchingSkills = job.requiredSkills.filter(skill => 
    userProfile.skills.some(userSkill => 
      userSkill.toLowerCase() === skill.toLowerCase()
    )
  );
  
  if (matchingSkills.length > 0) {
    reasons.push(`You have direct experience with key skills: ${matchingSkills.slice(0, 2).join(', ')}`);
  }
  
  return reasons.length > 0 ? reasons : ['Based on your overall profile and preferences'];
}