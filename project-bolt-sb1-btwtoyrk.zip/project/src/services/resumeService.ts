import { ResumeAnalysis } from '../types';

// Simulated AI resume analysis service
export async function analyzeResume(content: string, fileName: string): Promise<ResumeAnalysis> {
  // Simulate API processing time
  await new Promise(resolve => setTimeout(resolve, 3000));

  // Simulate AI analysis with realistic data extraction
  const analysis: ResumeAnalysis = {
    extractedSkills: extractSkills(content),
    suggestedInterests: suggestInterests(content),
    detectedExperience: detectExperienceLevel(content),
    detectedEducation: detectEducation(content),
    contactInfo: extractContactInfo(content),
    summary: generateSummary(content)
  };

  return analysis;
}

function extractSkills(content: string): string[] {
  const skillKeywords = [
    'JavaScript', 'Python', 'Java', 'React', 'Angular', 'Vue.js', 'Node.js', 'TypeScript',
    'HTML', 'CSS', 'SQL', 'MongoDB', 'PostgreSQL', 'MySQL', 'AWS', 'Azure', 'Docker',
    'Kubernetes', 'Git', 'Linux', 'Machine Learning', 'Data Analysis', 'TensorFlow',
    'PyTorch', 'Pandas', 'NumPy', 'Scikit-learn', 'Django', 'Flask', 'Express.js',
    'Spring Boot', 'REST API', 'GraphQL', 'Microservices', 'DevOps', 'CI/CD',
    'Agile', 'Scrum', 'Project Management', 'UI/UX Design', 'Figma', 'Adobe Creative Suite',
    'Photoshop', 'Illustrator', 'Sketch', 'Wireframing', 'Prototyping', 'User Research',
    'A/B Testing', 'Google Analytics', 'SEO', 'Digital Marketing', 'Content Marketing',
    'Social Media Marketing', 'Email Marketing', 'Salesforce', 'HubSpot', 'Tableau',
    'Power BI', 'Excel', 'R', 'MATLAB', 'C++', 'C#', '.NET', 'PHP', 'Ruby', 'Go',
    'Swift', 'Kotlin', 'Flutter', 'React Native', 'iOS Development', 'Android Development',
    'Mobile Development', 'Game Development', 'Unity', 'Unreal Engine', 'Blockchain',
    'Ethereum', 'Smart Contracts', 'Cryptocurrency', 'Cybersecurity', 'Penetration Testing',
    'Network Security', 'Information Security', 'CISSP', 'CEH', 'CompTIA Security+'
  ];

  const contentLower = content.toLowerCase();
  const foundSkills = skillKeywords.filter(skill => 
    contentLower.includes(skill.toLowerCase())
  );

  // Add some randomization to simulate AI uncertainty
  const additionalSkills = ['Problem Solving', 'Team Collaboration', 'Communication', 'Leadership'];
  const randomAdditional = additionalSkills.filter(() => Math.random() > 0.5);

  return [...new Set([...foundSkills, ...randomAdditional])].slice(0, 12);
}

function suggestInterests(content: string): string[] {
  const interestMapping: Record<string, string[]> = {
    'web': ['Web Development', 'Frontend Development', 'Backend Development'],
    'mobile': ['Mobile Development', 'iOS Development', 'Android Development'],
    'data': ['Data Science', 'Data Analysis', 'Big Data', 'Business Intelligence'],
    'ai': ['Artificial Intelligence', 'Machine Learning', 'Deep Learning', 'Natural Language Processing'],
    'cloud': ['Cloud Computing', 'AWS', 'Azure', 'DevOps'],
    'security': ['Cybersecurity', 'Information Security', 'Network Security'],
    'design': ['UI/UX Design', 'Graphic Design', 'Product Design'],
    'marketing': ['Digital Marketing', 'Content Marketing', 'Social Media Marketing'],
    'finance': ['Fintech', 'Financial Technology', 'Banking Technology'],
    'health': ['Healthcare Technology', 'Medical Software', 'Health Informatics'],
    'game': ['Game Development', 'Interactive Media', 'Entertainment Technology'],
    'blockchain': ['Blockchain', 'Cryptocurrency', 'DeFi', 'Web3'],
    'iot': ['Internet of Things', 'Embedded Systems', 'Smart Devices'],
    'startup': ['Startups', 'Entrepreneurship', 'Innovation'],
    'enterprise': ['Enterprise Software', 'Business Solutions', 'ERP Systems']
  };

  const contentLower = content.toLowerCase();
  const suggestedInterests: string[] = [];

  Object.entries(interestMapping).forEach(([keyword, interests]) => {
    if (contentLower.includes(keyword)) {
      suggestedInterests.push(...interests);
    }
  });

  // Remove duplicates and limit to 8 interests
  return [...new Set(suggestedInterests)].slice(0, 8);
}

function detectExperienceLevel(content: string): string {
  const contentLower = content.toLowerCase();
  
  if (contentLower.includes('senior') || contentLower.includes('lead') || 
      contentLower.includes('principal') || contentLower.includes('architect') ||
      contentLower.includes('manager') || contentLower.includes('director')) {
    return 'senior';
  }
  
  if (contentLower.includes('junior') || contentLower.includes('entry') || 
      contentLower.includes('intern') || contentLower.includes('graduate') ||
      contentLower.includes('associate')) {
    return 'entry';
  }

  // Count years of experience mentioned
  const yearMatches = content.match(/(\d+)\s*(?:years?|yrs?)/gi);
  if (yearMatches) {
    const years = yearMatches.map(match => parseInt(match.match(/\d+/)?.[0] || '0'));
    const maxYears = Math.max(...years);
    
    if (maxYears >= 8) return 'senior';
    if (maxYears >= 3) return 'mid';
    return 'entry';
  }

  return 'mid'; // Default
}

function detectEducation(content: string): string {
  const contentLower = content.toLowerCase();
  
  if (contentLower.includes('phd') || contentLower.includes('doctorate') || 
      contentLower.includes('ph.d')) {
    return 'doctorate';
  }
  
  if (contentLower.includes('master') || contentLower.includes('mba') || 
      contentLower.includes('ms') || contentLower.includes('ma') ||
      contentLower.includes('m.s') || contentLower.includes('m.a')) {
    return 'master';
  }
  
  if (contentLower.includes('bachelor') || contentLower.includes('bs') || 
      contentLower.includes('ba') || contentLower.includes('b.s') ||
      contentLower.includes('b.a') || contentLower.includes('degree')) {
    return 'bachelor';
  }
  
  if (contentLower.includes('associate') || contentLower.includes('aa') || 
      contentLower.includes('as') || contentLower.includes('a.a') ||
      contentLower.includes('a.s')) {
    return 'associate';
  }

  return 'bachelor'; // Default
}

function extractContactInfo(content: string): ResumeAnalysis['contactInfo'] {
  const contactInfo: ResumeAnalysis['contactInfo'] = {};

  // Extract email
  const emailMatch = content.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  if (emailMatch) {
    contactInfo.email = emailMatch[0];
  }

  // Extract phone
  const phoneMatch = content.match(/(?:\+?1[-.\s]?)?\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})/);
  if (phoneMatch) {
    contactInfo.phone = phoneMatch[0];
  }

  // Extract name (first line that looks like a name)
  const lines = content.split('\n').filter(line => line.trim());
  const namePattern = /^[A-Z][a-z]+\s+[A-Z][a-z]+/;
  const nameLine = lines.find(line => namePattern.test(line.trim()));
  if (nameLine) {
    contactInfo.name = nameLine.trim();
  }

  // Extract location (look for city, state patterns)
  const locationMatch = content.match(/([A-Z][a-z]+,\s*[A-Z]{2})|([A-Z][a-z]+\s*[A-Z][a-z]+,\s*[A-Z]{2})/);
  if (locationMatch) {
    contactInfo.location = locationMatch[0];
  }

  return contactInfo;
}

function generateSummary(content: string): string {
  // Simulate AI-generated summary based on content analysis
  const summaries = [
    "Experienced software developer with strong technical skills in modern web technologies and a proven track record of delivering high-quality applications. Demonstrates expertise in full-stack development with a focus on user experience and scalable solutions.",
    
    "Results-driven professional with extensive experience in data analysis and machine learning. Skilled in extracting insights from complex datasets and implementing data-driven solutions to solve business challenges.",
    
    "Creative and detail-oriented designer with expertise in user interface and user experience design. Passionate about creating intuitive and visually appealing digital experiences that enhance user engagement.",
    
    "Versatile technology professional with a strong background in cloud computing and DevOps practices. Experienced in designing and implementing scalable infrastructure solutions for enterprise applications.",
    
    "Dynamic marketing professional with expertise in digital marketing strategies and campaign management. Proven ability to drive brand awareness and customer engagement through innovative marketing initiatives."
  ];

  // Select summary based on content keywords
  const contentLower = content.toLowerCase();
  if (contentLower.includes('data') || contentLower.includes('analysis') || contentLower.includes('machine learning')) {
    return summaries[1];
  } else if (contentLower.includes('design') || contentLower.includes('ui') || contentLower.includes('ux')) {
    return summaries[2];
  } else if (contentLower.includes('cloud') || contentLower.includes('devops') || contentLower.includes('aws')) {
    return summaries[3];
  } else if (contentLower.includes('marketing') || contentLower.includes('campaign') || contentLower.includes('brand')) {
    return summaries[4];
  }
  
  return summaries[0]; // Default to software developer summary
}