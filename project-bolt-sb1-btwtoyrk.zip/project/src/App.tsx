import React, { useState, useEffect } from 'react';
import { User, Briefcase, Target, TrendingUp, Upload, Star, Filter, Search, LogOut } from 'lucide-react';
import Login from './components/Login';
import ResumeUpload from './components/ResumeUpload';
import Dashboard from './components/Dashboard';
import ProfileSetup from './components/ProfileSetup';
import JobRecommendations from './components/JobRecommendations';
import SkillAnalysis from './components/SkillAnalysis';
import { UserProfile, JobRecommendation, AuthState, ResumeAnalysis } from './types';
import { generateJobRecommendations } from './services/aiService';

function App() {
  const [authState, setAuthState] = useState<AuthState>({ isAuthenticated: false, user: null });
  const [currentView, setCurrentView] = useState<'login' | 'resume-upload' | 'setup' | 'dashboard' | 'recommendations' | 'analysis'>('login');
  const [jobRecommendations, setJobRecommendations] = useState<JobRecommendation[]>([]);

  useEffect(() => {
    if (authState.user) {
      const recommendations = generateJobRecommendations(authState.user);
      setJobRecommendations(recommendations);
    }
  }, [authState.user]);

  const handleLogin = (user: UserProfile) => {
    setAuthState({ isAuthenticated: true, user });
    
    // Check if user has completed profile setup
    if (user.skills.length === 0 || user.interests.length === 0 || !user.experience || !user.education) {
      setCurrentView('resume-upload');
    } else {
      setCurrentView('dashboard');
    }
  };

  const handleLogout = () => {
    setAuthState({ isAuthenticated: false, user: null });
    setCurrentView('login');
    setJobRecommendations([]);
  };

  const handleResumeAnalysisComplete = (analysis: ResumeAnalysis, updatedProfile: UserProfile) => {
    setAuthState(prev => ({ ...prev, user: updatedProfile }));
    
    // Check if profile is complete enough to skip manual setup
    if (updatedProfile.skills.length >= 3 && updatedProfile.interests.length >= 2) {
      setCurrentView('dashboard');
    } else {
      setCurrentView('setup');
    }
  };

  const handleSkipResumeUpload = () => {
    setCurrentView('setup');
  };
  const handleProfileComplete = (profile: UserProfile) => {
    setAuthState(prev => ({ ...prev, user: profile }));
    setCurrentView('dashboard');
  };

  // Show login if not authenticated
  if (!authState.isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Target className="w-8 h-8 text-blue-600" />
              <h1 className="ml-2 text-xl font-bold text-gray-900">AI JobMatch</h1>
            </div>
            
            {authState.user && currentView !== 'resume-upload' && currentView !== 'setup' && (
              <div className="flex items-center space-x-8">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                    currentView === 'dashboard' 
                      ? 'text-blue-600 bg-blue-50' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Briefcase className="w-4 h-4" />
                  <span>Dashboard</span>
                </button>
                
                <button
                  onClick={() => setCurrentView('recommendations')}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                    currentView === 'recommendations' 
                      ? 'text-blue-600 bg-blue-50' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Star className="w-4 h-4" />
                  <span>Jobs</span>
                </button>
                
                <button
                  onClick={() => setCurrentView('analysis')}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium ${
                    currentView === 'analysis' 
                      ? 'text-blue-600 bg-blue-50' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>Analysis</span>
                </button>
                
                <div className="flex items-center space-x-2">
                  <User className="w-6 h-6 text-gray-400" />
                  <span className="text-sm text-gray-700">{authState.user.name}</span>
                  <button
                    onClick={handleLogout}
                    className="ml-4 text-gray-400 hover:text-gray-600 p-1"
                    title="Logout"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        {currentView === 'resume-upload' && authState.user && (
          <ResumeUpload 
            userProfile={authState.user}
            onAnalysisComplete={handleResumeAnalysisComplete}
            onSkip={handleSkipResumeUpload}
          />
        )}
        
        {currentView === 'setup' && authState.user && (
          <ProfileSetup onComplete={handleProfileComplete} />
        )}
        
        {currentView === 'dashboard' && authState.user && (
          <Dashboard 
            userProfile={authState.user} 
            jobRecommendations={jobRecommendations}
            onViewRecommendations={() => setCurrentView('recommendations')}
          />
        )}
        
        {currentView === 'recommendations' && authState.user && (
          <JobRecommendations 
            userProfile={authState.user}
            jobRecommendations={jobRecommendations}
          />
        )}
        
        {currentView === 'analysis' && authState.user && (
          <SkillAnalysis userProfile={authState.user} />
        )}
      </main>
    </div>
  );
}

export default App;