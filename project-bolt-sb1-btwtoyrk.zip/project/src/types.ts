export interface UserProfile {
  id: string;
  name: string;
  email: string;
  password?: string;
  skills: string[];
  interests: string[];
  experience: string;
  education: string;
  location: string;
  resumeContent?: string;
  resumeFileName?: string;
  preferences: {
    jobType: 'full-time' | 'part-time' | 'contract' | 'internship';
    salaryRange: string;
    remoteWork: boolean;
  };
}

export interface AuthState {
  isAuthenticated: boolean;
  user: UserProfile | null;
}

export interface ResumeAnalysis {
  extractedSkills: string[];
  suggestedInterests: string[];
  detectedExperience: string;
  detectedEducation: string;
  contactInfo: {
    name?: string;
    email?: string;
    phone?: string;
    location?: string;
  };
  summary: string;
}

export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  salary: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  matchScore: number;
  skillsMatch: number;
  interestsMatch: number;
  compatibilityScore: number;
  skillGaps: string[];
  matchReasons: string[];
}

export interface SkillAnalysis {
  skill: string;
  proficiency: number;
  demand: number;
  growth: number;
  recommendations: string[];
}